#!/bin/bash
#
# 

cd /opt/gogs/

./gogs web &

